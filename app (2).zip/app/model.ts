
export class college{
    index:number=0;
name:string="";
address:string="";

}