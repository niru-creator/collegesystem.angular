import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './masterpage.html',
  styleUrls: ['./masterpage.component.css']

})
export class MasterpageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
