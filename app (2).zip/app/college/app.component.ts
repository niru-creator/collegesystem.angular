import { Component } from '@angular/core';
import { college } from '../model';
@Component({
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class collegeComponent {
 collegeobject:college=new college();
collectionobj:Array<college>=new Array<college>();
//add record
  Adddata(){
    console.log(this.collegeobject.index);
    this.collegeobject.index=this.collectionobj.length;
  this.collectionobj.push(this.collegeobject);
  console.log(this.collegeobject.index);

  this.collegeobject=new college();  //again creating a new object to empty the text box after clicking submit button
  }
 edit(p:college) {
var clz:college=new college();
clz.index=p.index;
clz.name=p.name;
clz.address=p.address;
this.collegeobject=clz;
console.log(clz.index);
}//update record
update()
{
  var colc:college=this.collectionobj[this.collegeobject.index];
  colc.name=this.collegeobject.name;
  colc.address=this.collegeobject.address;
console.log(colc.index);
this.collegeobject=new college(); //clear the text box
}

//delete operation
delete(i:college){
 console.log(i);
this.collectionobj.splice(0,1);
this.collegeobject=new college(); //clear the text box

 }



  title = 'Collegesystem';
}
